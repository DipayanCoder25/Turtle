import turtle

polygon=turtle.Turtle()
side=6
side_length=70
angel=360/side

for i in range(side):
    polygon.forward(side_length)
    polygon.right(angel)
polygon.done    

