import turtle

my_wn=turtle.Turtle()
size=0
while True:
  for i in range(4):
    my_wn.fd(size+1)
    my_wn.left(90)
    size-=5
  size+=1
  

